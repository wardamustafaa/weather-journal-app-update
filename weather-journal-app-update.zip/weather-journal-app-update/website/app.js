/* Global Variables */
const apiKey = '&appid=fee625b4373874c7144a8a05527acf25&units=imperial';
const baseURL = 'http://localhost:8000/';

const zipElement = document.getElementById('zip');
const feelingElement = document.getElementById('feelings');
const tempElement = document.getElementById('temp');
const dateElement = document.getElementById('date');
const contentElement = document.getElementById('content');

const catchError = (error) => console.error('there is an error ->' , error);

// Event listener to add function to existing HTML DOM element
let d = new Date();
let newDate = d.getMonth() +1 + "/" + d.getDate() + "/" + d.getFullYear();
document.getElementById('generate').addEventListener('click', toGenerate);
//toGenerate function
function toGenerate(){
    let data = {
        zip: zipElement.value,
        content: feelingElement.value,
        date: newDate
    };
    getZipCodeInfo(data.zip).then(zipInfo => {
        if(zipInfo.cod !=200)
        //return alert
        return alert(zipInfo.message)

        //get temperature
        data.temp = zipInfo.main.temp;
        //post data to server
        postInServer(data);
    }).catch(catchError);
};

async function getZipCodeInfo(zip){
    return await( await fetch(`http://api.openweathermap.org/data/2.5/weather?zip=${zip}${apiKey}`)).json()
}
/* Function to POST data */
async function postInServer(data){
    let response = await fetch(`${baseURL}addData` , {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data),
    });
    try {
        response.json().then(data => {
            if (response.ok)
                updateUI();
            else 
                alert('Not Successfull ,please try again');
        }).catch(catchError);
    } catch (error) {
        catchError(error);
    }
}

//update UI
async function updateUI() {
    let response = await fetch(`${baseURL}allData`);
    try{
        response.json().then(data => {
            dateElement.innerHTML = `Date: ${data.date}`;
            tempElement.innerHTML = `Temperature: ${data.temp}`;
            contentElement.innerHTML = `Feeling: ${data.content}`;
        }).catch(catchError);
    } catch (error) {
        catchError(error);
    }
}